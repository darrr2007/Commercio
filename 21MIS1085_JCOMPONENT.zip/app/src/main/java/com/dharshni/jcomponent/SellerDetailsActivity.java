package com.dharshni.jcomponent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.dharshni.jcomponent.R;

public class SellerDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_details);
    }
}